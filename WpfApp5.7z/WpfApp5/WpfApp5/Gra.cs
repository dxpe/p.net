﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp5
{
    enum Pole
    {
        puste, krzyzyk, kolo = 4
    }
    internal class Gra
    {
        int[,] plansza = new int[3, 3];
        Pole nextMove = Pole.krzyzyk;
        Pole doZwrotu;
        public Pole zrobRuch(int x, int y)
        {
            if (plansza[x, y] == 0)
            {
                plansza[x, y] = (int)nextMove;
                doZwrotu = nextMove;
                if (nextMove == Pole.krzyzyk)
                {
                    nextMove = Pole.kolo;
                }
                else
                {
                    nextMove = Pole.krzyzyk;
                }
                return doZwrotu;
            }
            return Pole.puste;
        }
        public Pole sprawdzWygrana()
        {
            int suma = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    {
                        suma += plansza[i, j];
                    }
                    if (suma == 3)
                    {
                        return Pole.krzyzyk;
                    }
                    else if (suma == 12)
                    {
                        return Pole.kolo;
                    }
                }
                suma = 0;
            }
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    {
                        suma += plansza[j, i];
                    }
                    if (suma == 3)
                    {
                        return Pole.krzyzyk;
                    }
                    else if (suma == 12)
                    {
                        return Pole.kolo;
                    }
                }
                suma = 0;
            }
            return Pole.puste;
        }
    }
}
